import {createClient} from '@supabase/supabase-js';
export const allowedEmail='lienmathieu2@gmail.com';
const url=import.meta.env.VITE_SUPABASE_URL;
const key=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
export const supabase=url && key ? createClient(url,key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'grenier2-auth',flowType:'implicit'}}):null;
export function client(){if(!supabase)throw Error('La connexion n’est pas encore configurée.');return supabase;}
